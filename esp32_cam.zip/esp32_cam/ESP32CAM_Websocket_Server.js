

const WebSocket = require('ws')
const fs = require('fs')


const wss = new WebSocket.Server({ port: 8002 })


var cams = [];
wss.on('connection', (ws) => {
  console.log('Connected')
  ws.on('message', (msg) => {
    camNo = msg[12] + (msg[13] << 8) + (msg[14] << 16) + (msg[15] << 32);
    temperature = msg[16]
    humidity = msg[17]


    //console.log(camNo, temperature, humidity)
    fs.writeFileSync('images/' + camNo + '.jpg', msg)


    const eventData = { imageId: camNo }
    clients.forEach((res,clientId) => {
      res.write(`event: updateImageSSE\n`)
      res.write(`data: ${JSON.stringify(eventData)}\n\n`)
    })
  })


  ws.on('close', () => {
    console.log('disconnection')
  })
})


//============================
// HTTP image request Service
//============================


const express = require('express')
const url = require('url')


const app = express()
const HTTP_PORT = 8001


app.use(function(req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});


app.use(express.static('.'))
app.get('/', function(req, res) {
  res.sendFile(__dirname + '/ESP32CAM_WebApp.html');
})


var clients = new Map()
app.get('/updateImageSSE', (req, res) => {
  const { clientId } = url.parse(req.url, true).query
  console.log('updateImageSSE request id', clientId)


  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',    
  })


  clients.set(clientId, res);
  console.log("Add client", clientId, "SSE length:", clients.size)


  req.on('close', () => {
    clients.delete(clientId)
    console.log("Add client", clientId, "SSE length:", clients.size)
  })
})


app.listen(HTTP_PORT, () => {
  console.log("HTTP Server listening at " + HTTP_PORT)
})







